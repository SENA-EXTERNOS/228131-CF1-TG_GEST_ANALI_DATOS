function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5lm6vxCggWw":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

